// lib/core/models/user_model.dart

class UserModel {
  final String id;
  final String email;
  final String name;
  final String role;
  final String tenantId;

  const UserModel({
    required this.id,
    required this.email,
    required this.name,
    required this.role,
    required this.tenantId,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'] as String,
        email: json['email'] as String,
        name: json['name'] as String,
        role: json['role'] as String,
        tenantId: (json['tenant_id'] ?? '') as String,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'name': name,
        'role': role,
        'tenant_id': tenantId,
      };
}

// lib/core/models/tenant_model.dart
class TenantModel {
  final String id;
  final String name;
  final String slug;

  const TenantModel({
    required this.id,
    required this.name,
    required this.slug,
  });

  factory TenantModel.fromJson(Map<String, dynamic> json) => TenantModel(
        id: json['id'] as String,
        name: json['name'] as String,
        slug: json['slug'] as String,
      );
}
