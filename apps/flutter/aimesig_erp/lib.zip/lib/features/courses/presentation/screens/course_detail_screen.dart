// lib/features/courses/presentation/screens/course_detail_screen.dart
import 'package:flutter/material.dart';
import '../../courses_service.dart';

class CourseDetailScreen extends StatefulWidget {
  const CourseDetailScreen({super.key, required this.id});
  final String id;
  @override State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}
class _CourseDetailScreenState extends State<CourseDetailScreen>
    with SingleTickerProviderStateMixin {
  final _svc = CoursesService();
  Map<String, dynamic>? _course;
  List<dynamic> _batches = [];
  List<dynamic> _members = [];
  late final TabController _tabs;
  bool _loading = true;

  @override void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _load();
  }
  @override void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await Future.wait(<Future<dynamic>>[
        _svc.getCourse(widget.id),
        _svc.getBatches(widget.id),
        _svc.getCourseMembers(widget.id),
      ]);
      setState(() {
        _course  = res[0] as Map<String, dynamic>;
        _batches = res[1] as List<dynamic>;
        _members = res[2] as List<dynamic>;
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(_course?['name'] ?? 'Course'),
      bottom: TabBar(
        controller: _tabs,
        tabs: const [Tab(text: 'Batches'), Tab(text: 'Members')],
      ),
    ),
    body: _loading ? const Center(child: CircularProgressIndicator())
      : TabBarView(
          controller: _tabs,
          children: [
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _batches.length,
              itemBuilder: (_, i) {
                final b = _batches[i] as Map<String, dynamic>;
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(b['name'] as String),
                    subtitle: Text('${b['enrolled_count'] ?? 0} enrolled'),
                    trailing: Text(b['status'] ?? ''),
                  ),
                );
              },
            ),
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _members.length,
              itemBuilder: (_, i) {
                final m = _members[i] as Map<String, dynamic>;
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(m['name'] as String),
                    subtitle: Text(m['batch_name'] ?? ''),
                    trailing: Text(m['enrollment_status'] ?? ''),
                  ),
                );
              },
            ),
          ],
        ),
  );
}
