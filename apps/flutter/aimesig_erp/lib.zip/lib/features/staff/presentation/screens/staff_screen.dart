// lib/features/staff/presentation/screens/staff_screen.dart
import 'package:flutter/material.dart';
import '../../staff_service.dart';

class StaffScreen extends StatefulWidget {
  const StaffScreen({super.key});
  @override State<StaffScreen> createState() => _StaffScreenState();
}

class _StaffScreenState extends State<StaffScreen> {
  final _svc    = StaffService();
  final _search = TextEditingController();
  List<dynamic> _staff   = [];
  bool          _loading = true;

  @override void initState() { super.initState(); _load(); }
  @override void dispose()   { _search.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _staff = await _svc.getStaff(
        search: _search.text.isEmpty ? null : _search.text.trim(),
      );
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _showAddStaff() async {
    final formKey    = GlobalKey<FormState>();
    final nameCtrl   = TextEditingController();
    final emailCtrl  = TextEditingController();
    final phoneCtrl  = TextEditingController();
    final salaryCtrl = TextEditingController();
    String? role;
    String? department;
    bool saving = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  const Expanded(child: Text('Add Staff Member', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ]),
                const SizedBox(height: 12),
                TextFormField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'Full Name *', prefixIcon: Icon(Icons.person_outline)),
                  validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email *', prefixIcon: Icon(Icons.email_outlined)),
                  validator: (v) => (v == null || !v.contains('@')) ? 'Valid email required' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Phone', prefixIcon: Icon(Icons.phone_outlined)),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: role,
                      hint: const Text('Role *'),
                      decoration: const InputDecoration(labelText: 'Role'),
                      validator: (v) => v == null ? 'Select role' : null,
                      items: const [
                        DropdownMenuItem(value: 'teacher',   child: Text('Teacher')),
                        DropdownMenuItem(value: 'trainer',   child: Text('Trainer')),
                        DropdownMenuItem(value: 'admin',     child: Text('Admin')),
                        DropdownMenuItem(value: 'support',   child: Text('Support')),
                        DropdownMenuItem(value: 'accounts',  child: Text('Accounts')),
                        DropdownMenuItem(value: 'other',     child: Text('Other')),
                      ],
                      onChanged: (v) => setS(() => role = v),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: department,
                      hint: const Text('Department'),
                      decoration: const InputDecoration(labelText: 'Department'),
                      items: const [
                        DropdownMenuItem(value: 'academic',    child: Text('Academic')),
                        DropdownMenuItem(value: 'sports',      child: Text('Sports')),
                        DropdownMenuItem(value: 'arts',        child: Text('Arts')),
                        DropdownMenuItem(value: 'admin',       child: Text('Admin')),
                        DropdownMenuItem(value: 'operations',  child: Text('Operations')),
                      ],
                      onChanged: (v) => setS(() => department = v),
                    ),
                  ),
                ]),
                const SizedBox(height: 12),
                TextFormField(
                  controller: salaryCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Monthly Salary (₹)', prefixIcon: Icon(Icons.currency_rupee)),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: saving ? null : () async {
                    if (!formKey.currentState!.validate()) return;
                    setS(() => saving = true);
                    try {
                      await _svc.createStaff({
                        'name':  nameCtrl.text.trim(),
                        'email': emailCtrl.text.trim(),
                        if (phoneCtrl.text.trim().isNotEmpty) 'phone': phoneCtrl.text.trim(),
                        'role':  role,
                        if (department != null) 'department': department,
                        if (salaryCtrl.text.trim().isNotEmpty)
                          'salary': double.tryParse(salaryCtrl.text.trim()),
                      });
                      if (ctx.mounted) Navigator.pop(ctx, true);
                    } catch (e) {
                      setS(() => saving = false);
                      if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Error: $e')));
                    }
                  },
                  child: saving
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : const Text('Add Staff Member'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Staff (${_staff.length})')),
    body: Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: TextField(
          controller: _search,
          decoration: const InputDecoration(hintText: 'Search staff…', prefixIcon: Icon(Icons.search)),
          onChanged: (_) => _load(),
        ),
      ),
      const SizedBox(height: 8),
      Expanded(
        child: _loading ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: _staff.isEmpty
                ? const Center(child: Text('No staff found. Tap + to add.'))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _staff.length,
                    itemBuilder: (_, i) {
                      final s = _staff[i] as Map<String, dynamic>;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundImage: s['photo_url'] != null
                                ? NetworkImage(s['photo_url'] as String) : null,
                            child: s['photo_url'] == null
                                ? Text((s['name'] as String? ?? '?').substring(0,1).toUpperCase()) : null,
                          ),
                          title: Text(s['name'] as String? ?? ''),
                          subtitle: Text('${s['role'] ?? ''} • ${s['department'] ?? ''}'),
                          trailing: Text(s['status'] ?? '',
                            style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ),
                      );
                    },
                  ),
            ),
      ),
    ]),
    floatingActionButton: FloatingActionButton.extended(
      icon: const Icon(Icons.person_add_outlined),
      label: const Text('Add Staff'),
      onPressed: _showAddStaff,
    ),
  );
}