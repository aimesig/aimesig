// lib/features/auth/auth_service.dart

import 'package:dio/dio.dart';
import '../../core/api/api_constants.dart';
import '../../core/api/dio_client.dart';
import '../../core/models/user_model.dart';

class AuthService {
  final Dio _dio = DioClient.instance;

  /// Login with email + password. Optional tenant_slug for multi-tenant login.
  Future<({UserModel user, String token})> login({
    required String email,
    required String password,
    String? tenantSlug,
  }) async {
    final resp = await _dio.post(ApiConstants.login, data: {
      'email': email,
      'password': password,
      if (tenantSlug != null) 'tenant_slug': tenantSlug,
    });
    final token = resp.data['token'] as String;
    final user  = UserModel.fromJson(resp.data['user'] as Map<String, dynamic>);
    await DioClient.saveToken(token);
    return (user: user, token: token);
  }

  /// Register a new organisation + admin user
  Future<({UserModel user, String token, TenantModel tenant})> register({
    required String orgName,
    required String adminName,
    required String adminEmail,
    required String adminPassword,
    String? orgType,
    String? timezone,
    String? currency,
  }) async {
    final resp = await _dio.post(ApiConstants.register, data: {
      'org_name':       orgName,
      'admin_name':     adminName,
      'admin_email':    adminEmail,
      'admin_password': adminPassword,
      if (orgType  != null) 'org_type':  orgType,
      if (timezone != null) 'timezone':  timezone,
      if (currency != null) 'currency':  currency,
    });
    final token      = resp.data['token'] as String;
    final tenantJson = resp.data['tenant'] as Map<String, dynamic>;
    final userJson   = Map<String, dynamic>.from(resp.data['user'] as Map<String, dynamic>);
    // API omits tenant_id from user on register — backfill it from tenant object
    userJson['tenant_id'] ??= tenantJson['id'];
    final user   = UserModel.fromJson(userJson);
    final tenant = TenantModel.fromJson(tenantJson);
    await DioClient.saveToken(token);
    return (user: user, token: token, tenant: tenant);
  }

  Future<void> logout() => DioClient.clearToken();

  Future<bool> isLoggedIn() async {
    final t = await DioClient.getToken();
    return t != null;
  }
}
