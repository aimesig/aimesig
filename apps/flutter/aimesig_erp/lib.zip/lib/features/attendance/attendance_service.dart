// lib/features/attendance/attendance_service.dart

import 'package:dio/dio.dart';
import '../../core/api/api_constants.dart';
import '../../core/api/dio_client.dart';

class AttendanceService {
  final Dio _dio = DioClient.instance;

  /// Mark single attendance record
  Future<Map<String, dynamic>> markAttendance({
    String? memberId,
    String? staffId,
    String? slotId,
    required String date,
    required String status, // present | absent | late
    String? note,
  }) async {
    final resp = await _dio.post(
      '${ApiConstants.attendance}/mark',
      data: {
        if (memberId != null) 'member_id': memberId,
        if (staffId  != null) 'staff_id':  staffId,
        if (slotId   != null) 'slot_id':   slotId,
        'date':   date,
        'status': status,
        if (note != null) 'note': note,
      },
    );
    return resp.data as Map<String, dynamic>;
  }

  /// Bulk mark — pass list of {member_id, date, status, slot_id?}
  Future<Map<String, dynamic>> bulkMark(
      List<Map<String, dynamic>> records) async {
    final resp = await _dio.post(
      '${ApiConstants.attendance}/bulk-mark',
      data: {'records': records},
    );
    return resp.data as Map<String, dynamic>;
  }

  /// All records for a session / slot
  Future<List<dynamic>> getSessionAttendance(String slotId) async {
    final resp = await _dio
        .get('${ApiConstants.attendance}/session/$slotId');
    return resp.data as List<dynamic>;
  }

  /// Attendance history for one member
  Future<List<dynamic>> getMemberAttendance(
    String memberId, {
    String? from,
    String? to,
  }) async {
    final resp = await _dio.get(
      '${ApiConstants.attendance}/member/$memberId',
      queryParameters: {
        if (from != null) 'from': from,
        if (to   != null) 'to':   to,
      },
    );
    return resp.data as List<dynamic>;
  }

  /// Attendance report (aggregated by member)
  Future<List<dynamic>> getAttendanceReport({
    String? batchId,
    String? from,
    String? to,
  }) async {
    final resp = await _dio.get(
      '${ApiConstants.attendance}/report',
      queryParameters: {
        if (batchId != null) 'batch_id': batchId,
        if (from    != null) 'from': from,
        if (to      != null) 'to':   to,
      },
    );
    return resp.data as List<dynamic>;
  }
}
