// lib/features/attendance/presentation/screens/attendance_screen.dart
import 'package:flutter/material.dart';
import '../../attendance_service.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../features/members/members_service.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});
  @override State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  final _svc    = AttendanceService();
  final _memSvc = MembersService();
  List<dynamic> _report  = [];
  List<dynamic> _members = [];
  bool _loading = true;
  String _from = DateTime.now().subtract(const Duration(days: 30))
      .toIso8601String().substring(0, 10);
  String _to   = DateTime.now().toIso8601String().substring(0, 10);

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait<dynamic>([
        _svc.getAttendanceReport(from: _from, to: _to),
        _memSvc.getMembers(),
      ]);
      _report  = results[0] as List<dynamic>;
      _members = results[1] as List<dynamic>;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _showMarkAttendance() async {
    final formKey    = GlobalKey<FormState>();
    String? memberId;
    String  status   = 'present';
    String  date     = DateTime.now().toIso8601String().substring(0, 10);
    final   noteCtrl = TextEditingController();
    bool    saving   = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Form(
            key: formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                const Expanded(child: Text('Mark Attendance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
                IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
              ]),
              const SizedBox(height: 12),
              // Date picker row
              OutlinedButton.icon(
                icon: const Icon(Icons.calendar_today_outlined, size: 18),
                label: Text('Date: $date'),
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2020),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null)
                    setSheetState(() => date = picked.toIso8601String().substring(0, 10));
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: memberId,
                hint: const Text('Select Member *'),
                decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), labelText: 'Member'),
                items: _members.map((m) {
                  final member = m as Map<String, dynamic>;
                  return DropdownMenuItem<String>(
                    value: member['id'] as String,
                    child: Text(member['name'] as String? ?? ''),
                  );
                }).toList(),
                validator: (v) => v == null ? 'Select a member' : null,
                onChanged: (v) => setSheetState(() => memberId = v),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.check_circle_outline), labelText: 'Status'),
                items: const [
                  DropdownMenuItem(value: 'present', child: Text('Present')),
                  DropdownMenuItem(value: 'absent',  child: Text('Absent')),
                  DropdownMenuItem(value: 'late',    child: Text('Late')),
                ],
                onChanged: (v) => setSheetState(() => status = v ?? 'present'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: noteCtrl,
                decoration: const InputDecoration(labelText: 'Note (optional)', prefixIcon: Icon(Icons.notes_outlined)),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: saving ? null : () async {
                  if (!formKey.currentState!.validate()) return;
                  setSheetState(() => saving = true);
                  try {
                    await _svc.markAttendance(
                      memberId: memberId,
                      date: date,
                      status: status,
                      note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
                    );
                    if (ctx.mounted) Navigator.pop(ctx, true);
                  } catch (e) {
                    setSheetState(() => saving = false);
                    if (ctx.mounted)
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Error: $e')));
                  }
                },
                child: saving
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                  : const Text('Mark Attendance'),
              ),
            ]),
          ),
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Attendance'),
      actions: [
        IconButton(
          icon: const Icon(Icons.date_range_outlined),
          tooltip: 'Change date range',
          onPressed: () async {
            final range = await showDateRangePicker(
              context: context,
              firstDate: DateTime(2020),
              lastDate: DateTime.now(),
              initialDateRange: DateTimeRange(
                start: DateTime.parse(_from),
                end: DateTime.parse(_to),
              ),
            );
            if (range != null) {
              setState(() {
                _from = range.start.toIso8601String().substring(0, 10);
                _to   = range.end.toIso8601String().substring(0, 10);
              });
              _load();
            }
          },
        ),
      ],
    ),
    body: _loading ? const Center(child: CircularProgressIndicator())
      : RefreshIndicator(
          onRefresh: _load,
          child: _report.isEmpty
            ? const Center(child: Text('No attendance data for this period'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _report.length,
                itemBuilder: (_, i) {
                  final r = _report[i] as Map<String, dynamic>;
                  final pct = double.tryParse(r['pct']?.toString() ?? '0') ?? 0;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      title: Text(r['name'] as String? ?? ''),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 6),
                          LinearProgressIndicator(
                            value: pct / 100,
                            backgroundColor: Colors.grey.shade200,
                            color: pct >= 75 ? AppTheme.success
                                : pct >= 50 ? AppTheme.warning : AppTheme.error,
                          ),
                        ],
                      ),
                      trailing: Text('${pct.toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: pct >= 75 ? AppTheme.success
                              : pct >= 50 ? AppTheme.warning : AppTheme.error,
                        ),
                      ),
                    ),
                  );
                },
              ),
        ),
    floatingActionButton: FloatingActionButton.extended(
      icon: const Icon(Icons.how_to_reg_outlined),
      label: const Text('Mark Attendance'),
      onPressed: _showMarkAttendance,
    ),
  );
}