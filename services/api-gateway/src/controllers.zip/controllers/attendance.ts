import { Router, Request, Response } from 'express';
import { sql } from '../utils/db';

const router = Router();

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/** For a staff user, check that the given batch is assigned to them */
async function assertStaffCanAccessBatch(
  tenantId: string,
  staffId: string,
  batchId: string,
): Promise<boolean> {
  const [row] = await sql`
    SELECT id FROM batches
    WHERE id = ${batchId} AND tenant_id = ${tenantId} AND staff_id = ${staffId}
  `;
  return Boolean(row);
}

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/attendance/my-batches  (staff: list their assigned batches)
// ─────────────────────────────────────────────────────────────────────────────
router.get('/my-batches', async (req: Request, res: Response): Promise<void> => {
  const linkedStaffId = req.tenantUser?.linked_staff_id;
  if (!linkedStaffId) {
    res.status(403).json({ error: 'Only staff accounts can access this endpoint' });
    return;
  }

  const rows = await sql`
    SELECT b.id, b.name AS batch_name, b.schedule_time,
           c.id AS course_id, c.name AS course_name,
           COUNT(DISTINCT e.id) AS enrolled_count
    FROM   batches     b
    JOIN   courses     c ON c.id = b.course_id
    LEFT JOIN enrollments e ON e.batch_id = b.id AND e.status = 'active'
    WHERE  b.staff_id  = ${linkedStaffId}
      AND  b.tenant_id = ${req.tenantId!}
      AND  b.status    = 'active'
    GROUP  BY b.id, c.id
    ORDER  BY b.name
  `;
  res.json(rows);
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/attendance/batch/:batchId/members  (staff/admin: members for taking attendance)
// ─────────────────────────────────────────────────────────────────────────────
router.get('/batch/:batchId/members', async (req: Request, res: Response): Promise<void> => {
  const role = req.tenantUser?.role;
  const linkedStaffId = req.tenantUser?.linked_staff_id;

  // Staff can only access their own batches
  if (role === 'staff' && linkedStaffId) {
    const allowed = await assertStaffCanAccessBatch(
      req.tenantId!, linkedStaffId, req.params.batchId,
    );
    if (!allowed) {
      res.status(403).json({ error: 'This batch is not assigned to you' });
      return;
    }
  }

  const { date } = req.query as Record<string, string>;
  const targetDate = date || new Date().toISOString().substring(0, 10);

  const rows = await sql`
    SELECT
      m.id AS member_id, m.name AS member_name, m.member_no, m.photo_url,
      a.id AS attendance_id, a.status AS attendance_status, a.note
    FROM   enrollments e
    JOIN   members     m ON m.id = e.member_id
    LEFT JOIN attendance a
      ON  a.member_id = m.id
      AND a.tenant_id = ${req.tenantId!}
      AND a.date      = ${targetDate}::date
      AND a.batch_id  = ${req.params.batchId}
    WHERE  e.batch_id  = ${req.params.batchId}
      AND  e.tenant_id = ${req.tenantId!}
      AND  e.status    = 'active'
    ORDER  BY m.name
  `;
  res.json(rows);
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/attendance/mark
// ─────────────────────────────────────────────────────────────────────────────
router.post('/mark', async (req: Request, res: Response): Promise<void> => {
  const { member_id, staff_id, slot_id, batch_id, date, status, type, note } = req.body;
  if (!date || !status) {
    res.status(400).json({ error: 'date and status are required' });
    return;
  }

  const role = req.tenantUser?.role;
  const linkedStaffId = req.tenantUser?.linked_staff_id;

  // Staff: verify the batch being marked is their assigned batch
  if (role === 'staff' && linkedStaffId && batch_id) {
    const allowed = await assertStaffCanAccessBatch(
      req.tenantId!, linkedStaffId, batch_id,
    );
    if (!allowed) {
      res.status(403).json({ error: 'You can only mark attendance for your assigned batches' });
      return;
    }
  }

  const t = type || (member_id ? 'member' : 'staff');

  try {
    const [row] = await sql`
      INSERT INTO attendance
        (tenant_id, slot_id, batch_id, member_id, staff_id, type, status, date, note, marked_by)
      VALUES
        (${req.tenantId!}, ${slot_id || null}, ${batch_id || null},
         ${member_id || null}, ${staff_id || null},
         ${t}, ${status}, ${date}, ${note || null}, ${req.tenantUser!.id})
      ON CONFLICT (tenant_id, COALESCE(batch_id, '00000000-0000-0000-0000-000000000000'::uuid),
                   COALESCE(member_id, '00000000-0000-0000-0000-000000000000'::uuid), date)
      DO UPDATE SET status = EXCLUDED.status, note = EXCLUDED.note, marked_by = EXCLUDED.marked_by, updated_at = NOW()
      RETURNING *
    `;
    res.status(201).json(row);
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/attendance/bulk-mark  (mark full session for a batch)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/bulk-mark', async (req: Request, res: Response): Promise<void> => {
  const { batch_id, date, records } = req.body;
  // records: [{ member_id, status, note? }]
  if (!batch_id || !date || !Array.isArray(records) || !records.length) {
    res.status(400).json({ error: 'batch_id, date, and records[] are required' });
    return;
  }

  const role = req.tenantUser?.role;
  const linkedStaffId = req.tenantUser?.linked_staff_id;

  if (role === 'staff' && linkedStaffId) {
    const allowed = await assertStaffCanAccessBatch(req.tenantId!, linkedStaffId, batch_id);
    if (!allowed) {
      res.status(403).json({ error: 'You can only mark attendance for your assigned batches' });
      return;
    }
  }

  try {
    const results = await Promise.all(
      records.map((r: { member_id: string; status?: string; note?: string }) =>
        sql`
          INSERT INTO attendance
            (tenant_id, batch_id, member_id, type, status, date, note, marked_by)
          VALUES
            (${req.tenantId!}, ${batch_id}, ${r.member_id},
             'member', ${r.status || 'present'}, ${date},
             ${r.note || null}, ${req.tenantUser!.id})
          ON CONFLICT (tenant_id, COALESCE(batch_id, '00000000-0000-0000-0000-000000000000'::uuid),
                       COALESCE(member_id, '00000000-0000-0000-0000-000000000000'::uuid), date)
          DO UPDATE SET status = EXCLUDED.status, note = EXCLUDED.note,
                        marked_by = EXCLUDED.marked_by, updated_at = NOW()
          RETURNING id
        `,
      ),
    );
    res.json({ marked: results.filter((r) => r.length).length, total: records.length });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/attendance/session/:slotId
// ─────────────────────────────────────────────────────────────────────────────
router.get('/session/:slotId', async (req: Request, res: Response): Promise<void> => {
  const rows = await sql`
    SELECT a.*, m.name AS member_name
    FROM   attendance a
    LEFT JOIN members m ON m.id = a.member_id
    WHERE  a.slot_id = ${req.params.slotId} AND a.tenant_id = ${req.tenantId!}
  `;
  res.json(rows);
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/attendance/member/:memberId
// ─────────────────────────────────────────────────────────────────────────────
router.get('/member/:memberId', async (req: Request, res: Response): Promise<void> => {
  const role = req.tenantUser?.role;
  const linkedMemberId = req.tenantUser?.linked_member_id;

  // Members can only see their own attendance
  if (role === 'member' && linkedMemberId && linkedMemberId !== req.params.memberId) {
    res.status(403).json({ error: 'You can only view your own attendance' });
    return;
  }

  const { from, to } = req.query as Record<string, string>;
  const rows = await sql`
    SELECT a.*,
           b.name AS batch_name,
           c.name AS course_name
    FROM   attendance a
    LEFT JOIN batches b ON b.id = a.batch_id
    LEFT JOIN courses c ON c.id = b.course_id
    WHERE  a.member_id = ${req.params.memberId} AND a.tenant_id = ${req.tenantId!}
      AND  (${from || null}::date IS NULL OR a.date >= ${from || null}::date)
      AND  (${to   || null}::date IS NULL OR a.date <= ${to   || null}::date)
    ORDER  BY a.date DESC
  `;
  res.json(rows);
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/attendance/report
// ─────────────────────────────────────────────────────────────────────────────
router.get('/report', async (req: Request, res: Response): Promise<void> => {
  const { batch_id, from, to } = req.query as Record<string, string>;
  const role = req.tenantUser?.role;
  const linkedStaffId = req.tenantUser?.linked_staff_id;

  // Staff can only get reports for their batches
  if (role === 'staff' && linkedStaffId && batch_id) {
    const allowed = await assertStaffCanAccessBatch(req.tenantId!, linkedStaffId, batch_id);
    if (!allowed) {
      res.status(403).json({ error: 'You can only view reports for your assigned batches' });
      return;
    }
  }

  const rows = await sql`
    SELECT
      m.id, m.name, m.member_no,
      b.name AS batch_name,
      COUNT(*) FILTER (WHERE a.status = 'present') AS present,
      COUNT(*) FILTER (WHERE a.status = 'absent')  AS absent,
      COUNT(*) FILTER (WHERE a.status = 'late')    AS late,
      COUNT(*)                                      AS total,
      ROUND(
        100.0 * COUNT(*) FILTER (WHERE a.status = 'present') / NULLIF(COUNT(*), 0), 1
      ) AS pct
    FROM   attendance a
    JOIN   members m ON m.id = a.member_id
    LEFT JOIN batches b ON b.id = a.batch_id
    WHERE  a.tenant_id = ${req.tenantId!} AND a.type = 'member'
      AND  (${batch_id || null}::uuid IS NULL OR a.batch_id = ${batch_id || null}::uuid)
      AND  (${from     || null}::date IS NULL OR a.date >= ${from || null}::date)
      AND  (${to       || null}::date IS NULL OR a.date <= ${to   || null}::date)
    GROUP  BY m.id, m.name, m.member_no, b.name
    ORDER  BY pct DESC NULLS LAST
  `;
  res.json(rows);
});

export default router;