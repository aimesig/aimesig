import { Router, Request, Response } from 'express';
import { sql } from '../utils/db';

const router = Router();

// ── COURSES ──────────────────────────────────────────────────────────────────

// GET /erp/courses
router.get('/', async (req: Request, res: Response): Promise<void> => {
  const rows = await sql`
    SELECT c.*, COUNT(DISTINCT b.id) AS batch_count,
           COUNT(DISTINCT e.id) AS member_count
    FROM   courses c
    LEFT JOIN batches     b ON b.course_id = c.id AND b.tenant_id = c.tenant_id
    LEFT JOIN enrollments e ON e.batch_id  = b.id AND e.status    = 'active'
    WHERE  c.tenant_id = ${req.tenantId!}
    GROUP  BY c.id
    ORDER  BY c.created_at DESC
  `;
  res.json(rows);
});

// POST /erp/courses
router.post('/', async (req: Request, res: Response): Promise<void> => {
  const { name, code, description, category, duration, capacity, fee } = req.body;
  if (!name) { res.status(400).json({ error: 'name is required' }); return; }
  try {
    const [row] = await sql`
      INSERT INTO courses (tenant_id, name, code, description, category, duration, capacity, fee)
      VALUES (${req.tenantId!}, ${name}, ${code || null}, ${description || null},
              ${category || null}, ${duration || null}, ${capacity || null}, ${fee || 0})
      RETURNING *
    `;
    res.status(201).json(row);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /erp/courses/:id
router.get('/:id', async (req: Request, res: Response): Promise<void> => {
  const [row] = await sql`
    SELECT * FROM courses WHERE id = ${req.params.id} AND tenant_id = ${req.tenantId!}
  `;
  if (!row) { res.status(404).json({ error: 'Course not found' }); return; }
  res.json(row);
});

// PATCH /erp/courses/:id
router.patch('/:id', async (req: Request, res: Response): Promise<void> => {
  const { name, code, description, category, duration, capacity, fee, status } = req.body;
  const [row] = await sql`
    UPDATE courses SET
      name        = COALESCE(${name        || null}, name),
      code        = COALESCE(${code        || null}, code),
      description = COALESCE(${description || null}, description),
      category    = COALESCE(${category    || null}, category),
      duration    = COALESCE(${duration    || null}, duration),
      capacity    = COALESCE(${capacity    || null}::int, capacity),
      fee         = COALESCE(${fee         || null}::numeric, fee),
      status      = COALESCE(${status      || null}, status),
      updated_at  = NOW()
    WHERE id = ${req.params.id} AND tenant_id = ${req.tenantId!}
    RETURNING *
  `;
  if (!row) { res.status(404).json({ error: 'Course not found' }); return; }
  res.json(row);
});

// DELETE /erp/courses/:id
router.delete('/:id', async (req: Request, res: Response): Promise<void> => {
  await sql`DELETE FROM courses WHERE id = ${req.params.id} AND tenant_id = ${req.tenantId!}`;
  res.status(204).send();
});

// POST /erp/courses/:id/publish
router.post('/:id/publish', async (req: Request, res: Response): Promise<void> => {
  const [row] = await sql`
    UPDATE courses SET status = 'active', updated_at = NOW()
    WHERE id = ${req.params.id} AND tenant_id = ${req.tenantId!}
    RETURNING *
  `;
  if (!row) { res.status(404).json({ error: 'Course not found' }); return; }
  res.json(row);
});

// ── BATCHES ───────────────────────────────────────────────────────────────────

// GET /erp/courses/:id/batches
router.get('/:id/batches', async (req: Request, res: Response): Promise<void> => {
  // Staff sees only their assigned batches; admin sees all
  const role = req.tenantUser?.role;
  const linkedStaffId = req.tenantUser?.linked_staff_id;

  const rows = role === 'staff' && linkedStaffId
    ? await sql`
        SELECT b.*,
               COUNT(DISTINCT e.id) AS enrolled_count,
               s.name AS staff_name
        FROM   batches b
        LEFT JOIN enrollments e ON e.batch_id = b.id AND e.status = 'active'
        LEFT JOIN staff       s ON s.id = b.staff_id
        WHERE  b.course_id = ${req.params.id}
          AND  b.tenant_id = ${req.tenantId!}
          AND  b.staff_id  = ${linkedStaffId}
        GROUP  BY b.id, s.name
        ORDER  BY b.created_at DESC
      `
    : await sql`
        SELECT b.*,
               COUNT(DISTINCT e.id) AS enrolled_count,
               s.name AS staff_name
        FROM   batches b
        LEFT JOIN enrollments e ON e.batch_id = b.id AND e.status = 'active'
        LEFT JOIN staff       s ON s.id = b.staff_id
        WHERE  b.course_id = ${req.params.id} AND b.tenant_id = ${req.tenantId!}
        GROUP  BY b.id, s.name
        ORDER  BY b.created_at DESC
      `;

  res.json(rows);
});

// POST /erp/courses/:id/batches
router.post('/:id/batches', async (req: Request, res: Response): Promise<void> => {
  const { name, start_date, end_date, capacity, staff_id, schedule_time } = req.body;
  if (!name) { res.status(400).json({ error: 'name is required' }); return; }

  try {
    // Validate staff belongs to this tenant if provided
    if (staff_id) {
      const [staffRow] = await sql`
        SELECT id FROM staff WHERE id = ${staff_id} AND tenant_id = ${req.tenantId!}
      `;
      if (!staffRow) { res.status(400).json({ error: 'Staff not found in this organisation' }); return; }
    }

    const [row] = await sql`
      INSERT INTO batches (tenant_id, course_id, name, start_date, end_date, capacity, staff_id, schedule_time)
      VALUES (${req.tenantId!}, ${req.params.id}, ${name},
              ${start_date || null}, ${end_date || null}, ${capacity || null},
              ${staff_id || null}, ${schedule_time || null})
      RETURNING *
    `;
    res.status(201).json(row);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /erp/courses/:id/batches/:batchId
router.patch('/:id/batches/:batchId', async (req: Request, res: Response): Promise<void> => {
  const { name, start_date, end_date, capacity, status, staff_id, schedule_time } = req.body;
  const [row] = await sql`
    UPDATE batches SET
      name          = COALESCE(${name          || null}, name),
      start_date    = COALESCE(${start_date    || null}::date, start_date),
      end_date      = COALESCE(${end_date      || null}::date, end_date),
      capacity      = COALESCE(${capacity      || null}::int, capacity),
      status        = COALESCE(${status        || null}, status),
      staff_id      = COALESCE(${staff_id      || null}::uuid, staff_id),
      schedule_time = COALESCE(${schedule_time || null}, schedule_time)
    WHERE id = ${req.params.batchId} AND course_id = ${req.params.id} AND tenant_id = ${req.tenantId!}
    RETURNING *
  `;
  if (!row) { res.status(404).json({ error: 'Batch not found' }); return; }
  res.json(row);
});

// DELETE /erp/courses/:id/batches/:batchId
router.delete('/:id/batches/:batchId', async (req: Request, res: Response): Promise<void> => {
  await sql`
    DELETE FROM batches
    WHERE id = ${req.params.batchId} AND course_id = ${req.params.id} AND tenant_id = ${req.tenantId!}
  `;
  res.status(204).send();
});

// ── MEMBERS (enrollments) ─────────────────────────────────────────────────────

// GET /erp/courses/:id/members
router.get('/:id/members', async (req: Request, res: Response): Promise<void> => {
  const rows = await sql`
    SELECT m.id, m.name, m.email, m.phone, m.member_no,
           e.id AS enrollment_id, e.enrolled_on, e.status AS enrollment_status,
           b.id AS batch_id, b.name AS batch_name
    FROM   enrollments e
    JOIN   members m ON m.id = e.member_id
    JOIN   batches b ON b.id = e.batch_id
    WHERE  b.course_id = ${req.params.id} AND e.tenant_id = ${req.tenantId!}
    ORDER  BY m.name
  `;
  res.json(rows);
});

// POST /erp/courses/:id/members  — enroll a member into a batch of this course
router.post('/:id/members', async (req: Request, res: Response): Promise<void> => {
  const { member_id, batch_id } = req.body;
  if (!member_id || !batch_id) {
    res.status(400).json({ error: 'member_id and batch_id are required' });
    return;
  }

  try {
    // Verify batch belongs to this course + tenant
    const [batch] = await sql`
      SELECT id, capacity FROM batches
      WHERE id = ${batch_id} AND course_id = ${req.params.id} AND tenant_id = ${req.tenantId!}
    `;
    if (!batch) { res.status(404).json({ error: 'Batch not found in this course' }); return; }

    // Check capacity
    if (batch.capacity) {
      const [{ count }] = await sql`
        SELECT COUNT(*) FROM enrollments
        WHERE batch_id = ${batch_id} AND status = 'active'
      `;
      if (parseInt(count) >= batch.capacity) {
        res.status(409).json({ error: 'Batch is at full capacity' });
        return;
      }
    }

    // Verify member belongs to this tenant
    const [member] = await sql`
      SELECT id FROM members WHERE id = ${member_id} AND tenant_id = ${req.tenantId!}
    `;
    if (!member) { res.status(404).json({ error: 'Member not found' }); return; }

    const [row] = await sql`
      INSERT INTO enrollments (tenant_id, member_id, batch_id)
      VALUES (${req.tenantId!}, ${member_id}, ${batch_id})
      ON CONFLICT (member_id, batch_id) DO UPDATE SET status = 'active', updated_at = NOW()
      RETURNING *
    `;
    res.status(201).json(row);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /erp/courses/:id/members/:enrollmentId — remove from batch
router.delete('/:id/members/:enrollmentId', async (req: Request, res: Response): Promise<void> => {
  const [row] = await sql`
    UPDATE enrollments SET status = 'dropped', updated_at = NOW()
    WHERE  id = ${req.params.enrollmentId}
      AND  tenant_id = ${req.tenantId!}
      AND  batch_id IN (SELECT id FROM batches WHERE course_id = ${req.params.id})
    RETURNING id
  `;
  if (!row) { res.status(404).json({ error: 'Enrollment not found' }); return; }
  res.status(204).send();
});

export default router;