import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { sql } from '../utils/db';
import { config } from '../config';
import { logger } from '../utils/logger';

const router = Router();

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/** e.g. "John Doe" → "john.doe" */
function toUsernameBase(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '.')
    .replace(/[^a-z0-9.]/g, '');
}

/** Generate a secure random password: 10 chars, mixed */
function generatePassword(): string {
  const chars =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$';
  const bytes = crypto.randomBytes(10);
  return Array.from(bytes)
    .map((b) => chars[b % chars.length])
    .join('');
}

/** Build a unique username@aimesig.com address */
async function buildUniqueEmail(
  tenantId: string,
  baseName: string,
): Promise<string> {
  const base = toUsernameBase(baseName);
  for (let i = 0; i < 50; i++) {
    const candidate = i === 0 ? `${base}@aimesig.com` : `${base}${i}@aimesig.com`;
    const [existing] = await sql`
      SELECT id FROM tenant_users
      WHERE email = ${candidate} AND tenant_id = ${tenantId}
    `;
    if (!existing) return candidate;
  }
  // Fallback: append random suffix
  return `${base}.${crypto.randomBytes(3).toString('hex')}@aimesig.com`;
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/register  – create tenant + first admin
// ─────────────────────────────────────────────────────────────────────────────
router.post('/register', async (req: Request, res: Response): Promise<void> => {
  const {
    org_name, org_type, timezone, currency,
    admin_name, admin_email, admin_password,
  } = req.body;

  if (!org_name || !admin_email || !admin_password || !admin_name) {
    res.status(400).json({
      error: 'org_name, admin_name, admin_email, admin_password are required',
    });
    return;
  }

  try {
    const slug =
      org_name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') +
      '-' + Date.now().toString(36);

    const hash = await bcrypt.hash(admin_password, 12);

    const [tenant] = await sql`
      INSERT INTO tenants (name, slug, type, timezone, currency)
      VALUES (${org_name}, ${slug}, ${org_type || 'school'}, ${timezone || 'Asia/Kolkata'}, ${currency || 'INR'})
      RETURNING id, name, slug
    `;
    const [user] = await sql`
      INSERT INTO tenant_users (tenant_id, email, password, name, role)
      VALUES (${tenant.id}, ${admin_email.toLowerCase()}, ${hash}, ${admin_name}, 'tenant_admin')
      RETURNING id, email, name, role
    `;

    const token = jwt.sign(
      { sub: user.id, email: user.email, role: user.role, tenant_id: tenant.id },
      config.jwt.secret,
      { expiresIn: config.jwt.expiresIn } as any,
    );

    res.status(201).json({
      tenant,
      user: { id: user.id, email: user.email, name: user.name, role: user.role },
      token,
    });
  } catch (err: any) {
    if (err.message?.includes('unique')) {
      res.status(409).json({ error: 'Email or org slug already exists' });
    } else {
      logger.error('register error', { error: err.message });
      res.status(500).json({ error: 'Registration failed' });
    }
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/login
// ─────────────────────────────────────────────────────────────────────────────
router.post('/login', async (req: Request, res: Response): Promise<void> => {
  const { email, password, tenant_slug } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'email and password are required' });
    return;
  }

  try {
    const rows = await (tenant_slug
      ? sql`
          SELECT tu.id, tu.email, tu.name, tu.role, tu.password, tu.tenant_id,
                 tu.is_active, t.is_active AS tenant_active,
                 tu.must_change_password, tu.linked_staff_id, tu.linked_member_id
          FROM   tenant_users tu
          JOIN   tenants t ON t.id = tu.tenant_id
          WHERE  tu.email = ${email.toLowerCase()} AND t.slug = ${tenant_slug}
        `
      : sql`
          SELECT tu.id, tu.email, tu.name, tu.role, tu.password, tu.tenant_id,
                 tu.is_active, t.is_active AS tenant_active,
                 tu.must_change_password, tu.linked_staff_id, tu.linked_member_id
          FROM   tenant_users tu
          JOIN   tenants t ON t.id = tu.tenant_id
          WHERE  tu.email = ${email.toLowerCase()}
          LIMIT  1
        `);

    if (!rows.length || !(await bcrypt.compare(password, rows[0].password))) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const u = rows[0];
    if (!u.is_active)     { res.status(403).json({ error: 'Account disabled' });       return; }
    if (!u.tenant_active) { res.status(403).json({ error: 'Organisation suspended' }); return; }

    await sql`UPDATE tenant_users SET last_login = NOW() WHERE id = ${u.id}`;

    const token = jwt.sign(
      {
        sub: u.id,
        email: u.email,
        role: u.role,
        tenant_id: u.tenant_id,
        linked_staff_id: u.linked_staff_id ?? undefined,
        linked_member_id: u.linked_member_id ?? undefined,
      },
      config.jwt.secret,
      { expiresIn: config.jwt.expiresIn } as any,
    );

    res.json({
      token,
      user: {
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        tenant_id: u.tenant_id,
        must_change_password: u.must_change_password,
        linked_staff_id: u.linked_staff_id ?? null,
        linked_member_id: u.linked_member_id ?? null,
      },
    });
  } catch (err: any) {
    logger.error('login error', { error: err.message });
    res.status(500).json({ error: 'Login failed' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/refresh
// ─────────────────────────────────────────────────────────────────────────────
router.post('/refresh', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) {
    res.status(401).json({ error: 'No token' });
    return;
  }
  try {
    const old = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    const [u] = await sql`
      SELECT id, email, name, role, tenant_id, is_active,
             linked_staff_id, linked_member_id
      FROM   tenant_users WHERE id = ${old.sub}
    `;
    if (!u || !u.is_active) {
      res.status(401).json({ error: 'User not found or inactive' });
      return;
    }
    const token = jwt.sign(
      {
        sub: u.id, email: u.email, role: u.role, tenant_id: u.tenant_id,
        linked_staff_id: u.linked_staff_id ?? undefined,
        linked_member_id: u.linked_member_id ?? undefined,
      },
      config.jwt.secret,
      { expiresIn: config.jwt.expiresIn } as any,
    );
    res.json({ token });
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/change-password  (authenticated; first-login reset)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/change-password', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) {
    res.status(400).json({ error: 'current_password and new_password required' });
    return;
  }
  if ((new_password as string).length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters' });
    return;
  }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    const [u] = await sql`SELECT id, password FROM tenant_users WHERE id = ${payload.sub}`;
    if (!u) { res.status(404).json({ error: 'User not found' }); return; }

    if (!(await bcrypt.compare(current_password, u.password))) {
      res.status(401).json({ error: 'Current password is incorrect' });
      return;
    }

    const hash = await bcrypt.hash(new_password, 12);
    await sql`
      UPDATE tenant_users
      SET password = ${hash}, must_change_password = false, updated_at = NOW()
      WHERE id = ${u.id}
    `;
    res.json({ message: 'Password updated successfully' });
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/reset-password-by-admin  (admin only — reset any user's pwd)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/reset-password-by-admin', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    if (payload.role !== 'tenant_admin') {
      res.status(403).json({ error: 'Admin access required' });
      return;
    }

    const { user_id } = req.body;
    if (!user_id) { res.status(400).json({ error: 'user_id required' }); return; }

    const [u] = await sql`
      SELECT id, name, email FROM tenant_users
      WHERE id = ${user_id} AND tenant_id = ${payload.tenant_id}
    `;
    if (!u) { res.status(404).json({ error: 'User not found' }); return; }

    const newPassword = generatePassword();
    const hash = await bcrypt.hash(newPassword, 12);

    await sql`
      UPDATE tenant_users
      SET password = ${hash}, must_change_password = true, updated_at = NOW()
      WHERE id = ${u.id}
    `;

    res.json({
      message: 'Password reset successfully',
      user: { id: u.id, name: u.name, email: u.email },
      temporary_password: newPassword,
    });
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/provision-staff  (admin: create @aimesig.com login for staff)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/provision-staff', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    if (payload.role !== 'tenant_admin') {
      res.status(403).json({ error: 'Admin access required' });
      return;
    }

    const { staff_id } = req.body;
    if (!staff_id) { res.status(400).json({ error: 'staff_id required' }); return; }

    // Verify staff belongs to this tenant
    const [staff] = await sql`
      SELECT id, name, email FROM staff
      WHERE id = ${staff_id} AND tenant_id = ${payload.tenant_id}
    `;
    if (!staff) { res.status(404).json({ error: 'Staff not found' }); return; }

    // Check if already provisioned
    const [existing] = await sql`
      SELECT id, email FROM tenant_users
      WHERE linked_staff_id = ${staff_id} AND tenant_id = ${payload.tenant_id}
    `;
    if (existing) {
      res.status(409).json({
        error: 'Staff already has a login account',
        existing_email: existing.email,
      });
      return;
    }

    const aimesigEmail = await buildUniqueEmail(payload.tenant_id, staff.name);
    const tempPassword = generatePassword();
    const hash = await bcrypt.hash(tempPassword, 12);

    const [user] = await sql`
      INSERT INTO tenant_users
        (tenant_id, email, password, name, role, linked_staff_id, must_change_password)
      VALUES
        (${payload.tenant_id}, ${aimesigEmail}, ${hash}, ${staff.name},
         'staff', ${staff_id}, true)
      RETURNING id, email, name, role, linked_staff_id
    `;

    res.status(201).json({
      message: 'Staff login created',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        linked_staff_id: user.linked_staff_id,
      },
      temporary_password: tempPassword,
    });
  } catch (err: any) {
    logger.error('provision-staff error', { error: err.message });
    res.status(500).json({ error: 'Provisioning failed' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/provision-member  (admin: create @aimesig.com login for member)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/provision-member', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    if (payload.role !== 'tenant_admin') {
      res.status(403).json({ error: 'Admin access required' });
      return;
    }

    const { member_id } = req.body;
    if (!member_id) { res.status(400).json({ error: 'member_id required' }); return; }

    const [member] = await sql`
      SELECT id, name, email FROM members
      WHERE id = ${member_id} AND tenant_id = ${payload.tenant_id}
    `;
    if (!member) { res.status(404).json({ error: 'Member not found' }); return; }

    const [existing] = await sql`
      SELECT id, email FROM tenant_users
      WHERE linked_member_id = ${member_id} AND tenant_id = ${payload.tenant_id}
    `;
    if (existing) {
      res.status(409).json({
        error: 'Member already has a login account',
        existing_email: existing.email,
      });
      return;
    }

    const aimesigEmail = await buildUniqueEmail(payload.tenant_id, member.name);
    const tempPassword = generatePassword();
    const hash = await bcrypt.hash(tempPassword, 12);

    const [user] = await sql`
      INSERT INTO tenant_users
        (tenant_id, email, password, name, role, linked_member_id, must_change_password)
      VALUES
        (${payload.tenant_id}, ${aimesigEmail}, ${hash}, ${member.name},
         'member', ${member_id}, true)
      RETURNING id, email, name, role, linked_member_id
    `;

    res.status(201).json({
      message: 'Member login created',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        linked_member_id: user.linked_member_id,
      },
      temporary_password: tempPassword,
    });
  } catch (err: any) {
    logger.error('provision-member error', { error: err.message });
    res.status(500).json({ error: 'Provisioning failed' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /erp/auth/users  (admin: list all provisioned users)
// ─────────────────────────────────────────────────────────────────────────────
router.get('/users', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    if (payload.role !== 'tenant_admin') {
      res.status(403).json({ error: 'Admin access required' });
      return;
    }

    const rows = await sql`
      SELECT
        tu.id, tu.email, tu.name, tu.role, tu.is_active,
        tu.must_change_password, tu.last_login,
        tu.linked_staff_id, tu.linked_member_id,
        s.name  AS staff_name,
        m.name  AS member_name
      FROM   tenant_users tu
      LEFT JOIN staff   s ON s.id = tu.linked_staff_id
      LEFT JOIN members m ON m.id = tu.linked_member_id
      WHERE  tu.tenant_id = ${payload.tenant_id}
      ORDER  BY tu.created_at DESC
    `;
    res.json(rows);
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /erp/auth/users/:id  (admin: enable/disable user)
// ─────────────────────────────────────────────────────────────────────────────
router.patch('/users/:id', async (req: Request, res: Response): Promise<void> => {
  const auth = req.headers['authorization'];
  if (!auth?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }

  try {
    const payload = jwt.verify(auth.slice(7), config.jwt.secret) as any;
    if (payload.role !== 'tenant_admin') {
      res.status(403).json({ error: 'Admin access required' });
      return;
    }

    const { is_active } = req.body;
    const [row] = await sql`
      UPDATE tenant_users
      SET is_active = ${Boolean(is_active)}, updated_at = NOW()
      WHERE id = ${req.params.id} AND tenant_id = ${payload.tenant_id}
      RETURNING id, email, name, role, is_active
    `;
    if (!row) { res.status(404).json({ error: 'User not found' }); return; }
    res.json(row);
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /erp/auth/forgot-password  (future: email reset)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/forgot-password', async (_req: Request, res: Response): Promise<void> => {
  res.json({ message: 'If that email exists, a reset link has been sent.' });
});

export default router;