import mongoose, { Schema } from 'mongoose';
import axios from 'axios';

// ── OTP document (auto-expires in 5 minutes via TTL index) ──────────────────
interface IOtp {
  phone: string;
  code: string;
  attempts: number;
  createdAt: Date;
}

const OtpSchema = new Schema<IOtp>({
  phone:     { type: String, required: true },
  code:      { type: String, required: true },
  attempts:  { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now, expires: 300 }, // TTL: 5 min
});

const Otp = mongoose.model<IOtp>('Otp', OtpSchema);

// ── Helpers ─────────────────────────────────────────────────────────────────
function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendViaMSG91(phone: string, code: string): Promise<void> {
  const { MSG91_AUTH_KEY, MSG91_TEMPLATE_ID } = process.env;
  if (!MSG91_AUTH_KEY || !MSG91_TEMPLATE_ID) {
    // Dev fallback — log to console
    console.log(`[OTP] Phone: ${phone}  Code: ${code}`);
    return;
  }

  await axios.post(
    'https://control.msg91.com/api/v5/otp',
    {
      template_id: MSG91_TEMPLATE_ID,
      mobile: phone.replace('+', ''),
      otp: code,
    },
    { headers: { authkey: MSG91_AUTH_KEY } }
  );
}

// ── Public API ───────────────────────────────────────────────────────────────
export async function sendOtp(phone: string): Promise<void> {
  // Remove any existing OTP for this phone
  await Otp.deleteMany({ phone });

  const code = generateOtp();
  await Otp.create({ phone, code });
  await sendViaMSG91(phone, code);
}

export async function verifyOtp(
  phone: string,
  code: string
): Promise<{ valid: boolean; reason?: string }> {
  const record = await Otp.findOne({ phone });

  if (!record) {
    return { valid: false, reason: 'OTP expired or not found' };
  }

  // Limit brute-force attempts
  if (record.attempts >= 5) {
    await record.deleteOne();
    return { valid: false, reason: 'Too many attempts. Request a new OTP.' };
  }

  if (record.code !== code) {
    record.attempts += 1;
    await record.save();
    return { valid: false, reason: 'Invalid OTP' };
  }

  await record.deleteOne(); // consumed
  return { valid: true };
}
