import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  phone:        string;
  username:     string;
  email:        string;       // auto-set to username@aimesig.com
  firebaseUid:  string;       // from Firebase Auth
  displayName?: string;
  avatar?:      string;
  isVerified:   boolean;
  role:         'user' | 'admin';
  tenantId?:    string | null;
  createdAt:    Date;
  updatedAt:    Date;
}

const UserSchema = new Schema<IUser>(
  {
    phone: {
      type: String, required: true, unique: true, trim: true,
      match: /^\+?[1-9]\d{9,14}$/,
    },
    username: {
      type: String, required: true, unique: true,
      lowercase: true, trim: true,
      match: /^[a-z0-9_]{3,30}$/,
    },
    email: {
      type: String, required: true, unique: true, lowercase: true,
    },
    firebaseUid: {
      type: String, required: true, unique: true,
    },
    displayName: { type: String, trim: true },
    avatar:      { type: String },
    isVerified:  { type: Boolean, default: false },
    role:        { type: String, enum: ['user', 'admin'], default: 'user' },
    tenantId:    { type: String, default: null },
  },
  { timestamps: true }
);

// Auto-generate email from username
UserSchema.pre('save', function (next) {
  if (this.isModified('username') || this.isNew) {
    this.email = `${this.username}@aimesig.com`;
  }
  next();
});

export const User = mongoose.model<IUser>('User', UserSchema);
